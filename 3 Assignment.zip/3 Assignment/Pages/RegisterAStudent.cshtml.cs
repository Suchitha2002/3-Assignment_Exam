using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace _3_Assignment.Pages
{
    public class RegisterAStudentModel : PageModel
    {

		public int Id { get; set; }
		public string Name { get; set; }
		public string Qualification { get;  set; }
		public string skill { get;  set; }
		public void OnGet()
        {
        }
    }
}
