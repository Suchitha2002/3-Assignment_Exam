using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace _3_Assignment.Pages.AllStudentsModel
{
    public class AllStudentsModel : PageModel
    {
        static List<AllStudentsModel> RegisterAStudentModel = new List<AllStudentsModel>();
        [BindProperty]
        public AllStudentsModel student1 { get; set; }
        public List<AllStudentsModel> list
        {
            get { return RegisterAStudentModel; }
        }

        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            RegisterAStudentModel.Add(student1);
            return RedirectToPage("AllStudents");
        }


    }
}