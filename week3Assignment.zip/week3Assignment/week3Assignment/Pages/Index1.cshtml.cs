using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace week3Assignment.Pages
{
    public class Index1Model : PageModel
    {
        public class Student
 {
     public int studentId { get; set; }
     public string Name { get; set; }

     public string qualification { get; set; }

     public string skill {�get;�set;�}
�}
        public void OnGet()
        {
        }
    }
}
