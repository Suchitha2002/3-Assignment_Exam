using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static week3Assignment.Pages.Index1Model;

namespace week3Assignment.Pages
{
    public class Index2Model : PageModel
    {
        static List<Student> students = new List<Student>();

        [BindProperty]
        public Student student { get; set; }
        public List<Student> List
        {
            get { return students; }
        }
        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {

            students.Add(student);
            return RedirectToPage("Index1");

        }
       
    }
}
